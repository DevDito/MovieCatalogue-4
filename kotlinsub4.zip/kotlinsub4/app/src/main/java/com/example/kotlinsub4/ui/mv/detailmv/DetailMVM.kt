package com.example.kotlinsub4.ui.mv.detailmv

import androidx.lifecycle.ViewModel
import com.example.kotlinsub4.ui.mv.pojo.ResultsItem

class DetailMVM : ViewModel() {
    var resultsItem: ResultsItem? = null
}
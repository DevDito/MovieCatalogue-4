package com.example.kotlinsub4.ui.fav

import android.app.Application
import androidx.lifecycle.AndroidViewModel

class FavViewModel (application: Application) : AndroidViewModel(application) {
}
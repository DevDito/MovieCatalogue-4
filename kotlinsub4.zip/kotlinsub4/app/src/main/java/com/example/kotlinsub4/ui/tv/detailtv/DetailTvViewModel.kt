package com.example.kotlinsub4.ui.tv.detailtv

import androidx.lifecycle.ViewModel
import com.example.kotlinsub4.ui.tv.pojo.ResultsItem

class DetailTvViewModel : ViewModel() {
    var resultsItem: ResultsItem? = null
}
